(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["reset-pass-reset-pass-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/reset-pass/reset-pass.page.html":
    /*!***************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/reset-pass/reset-pass.page.html ***!
      \***************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppResetPassResetPassPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=primary>\n    <ion-title>\n      Olvidaste tu contrasena?\n    </ion-title>\n    <ion-buttons slot=\"start\">\n      <ion-button routerLink=\"/..\">\n        <ion-icon name=\"arrow-back\" ></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content padding>\n  <ion-label  >\n    Escribe tu correo para enviarte las instrucciones para recuperar tu contrasena\n  </ion-label>\n  <ion-item>\n    <ion-input type=\"text\" [(ngModel)]=\"email\" name=\"email\"  placeholder=\"Ingrese su correo electronico\"></ion-input>\n  </ion-item>\n  <section>\n    <ion-button size=\"medium\" (click)=\"sendLinkReset()\">Recuperar Contrasena</ion-button>\n  </section>\n  \n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/reset-pass/reset-pass-routing.module.ts":
    /*!*********************************************************!*\
      !*** ./src/app/reset-pass/reset-pass-routing.module.ts ***!
      \*********************************************************/

    /*! exports provided: ResetPassPageRoutingModule */

    /***/
    function srcAppResetPassResetPassRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ResetPassPageRoutingModule", function () {
        return ResetPassPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _reset_pass_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./reset-pass.page */
      "./src/app/reset-pass/reset-pass.page.ts");

      var routes = [{
        path: '',
        component: _reset_pass_page__WEBPACK_IMPORTED_MODULE_3__["ResetPassPage"]
      }];

      var ResetPassPageRoutingModule = function ResetPassPageRoutingModule() {
        _classCallCheck(this, ResetPassPageRoutingModule);
      };

      ResetPassPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ResetPassPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/reset-pass/reset-pass.module.ts":
    /*!*************************************************!*\
      !*** ./src/app/reset-pass/reset-pass.module.ts ***!
      \*************************************************/

    /*! exports provided: ResetPassPageModule */

    /***/
    function srcAppResetPassResetPassModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ResetPassPageModule", function () {
        return ResetPassPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _reset_pass_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./reset-pass-routing.module */
      "./src/app/reset-pass/reset-pass-routing.module.ts");
      /* harmony import */


      var _reset_pass_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./reset-pass.page */
      "./src/app/reset-pass/reset-pass.page.ts");

      var ResetPassPageModule = function ResetPassPageModule() {
        _classCallCheck(this, ResetPassPageModule);
      };

      ResetPassPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _reset_pass_routing_module__WEBPACK_IMPORTED_MODULE_5__["ResetPassPageRoutingModule"]],
        declarations: [_reset_pass_page__WEBPACK_IMPORTED_MODULE_6__["ResetPassPage"]]
      })], ResetPassPageModule);
      /***/
    },

    /***/
    "./src/app/reset-pass/reset-pass.page.scss":
    /*!*************************************************!*\
      !*** ./src/app/reset-pass/reset-pass.page.scss ***!
      \*************************************************/

    /*! exports provided: default */

    /***/
    function srcAppResetPassResetPassPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "section {\n  margin: 15px;\n}\n\nion-item {\n  margin: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVzZXQtcGFzcy9yZXNldC1wYXNzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7QUFDSjs7QUFHQTtFQUNJLFlBQUE7QUFBSiIsImZpbGUiOiJzcmMvYXBwL3Jlc2V0LXBhc3MvcmVzZXQtcGFzcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJzZWN0aW9ue1xyXG4gICAgbWFyZ2luOiAxNXB4O1xyXG59XHJcblxyXG5cclxuaW9uLWl0ZW17XHJcbiAgICBtYXJnaW46IDE1cHg7XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "./src/app/reset-pass/reset-pass.page.ts":
    /*!***********************************************!*\
      !*** ./src/app/reset-pass/reset-pass.page.ts ***!
      \***********************************************/

    /*! exports provided: ResetPassPage */

    /***/
    function srcAppResetPassResetPassPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ResetPassPage", function () {
        return ResetPassPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/auth.service */
      "./src/app/services/auth.service.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

      var ResetPassPage = /*#__PURE__*/function () {
        function ResetPassPage(authService, router, toastC) {
          _classCallCheck(this, ResetPassPage);

          this.authService = authService;
          this.router = router;
          this.toastC = toastC;
        }

        _createClass(ResetPassPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "toastMessage",
          value: function toastMessage() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var toast;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.toastC.create({
                        message: "Mensaje Enviado",
                        duration: 2000
                      });

                    case 2:
                      toast = _context.sent;
                      toast.present();

                    case 4:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "sendLinkReset",
          value: function sendLinkReset() {
            var _this = this;

            this.authService.resetPassword(this.email).then(function () {
              console.log("Enviado");

              _this.toastMessage();

              _this.router.navigate(['/login']);
            })["catch"](function () {
              console.log("error");
            });
          }
        }]);

        return ResetPassPage;
      }();

      ResetPassPage.ctorParameters = function () {
        return [{
          type: _services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]
        }];
      };

      ResetPassPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-reset-pass',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./reset-pass.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/reset-pass/reset-pass.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./reset-pass.page.scss */
        "./src/app/reset-pass/reset-pass.page.scss"))["default"]]
      })], ResetPassPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=reset-pass-reset-pass-module-es5.js.map